import Portfolio from '../components/Portfolio';
//import Skills from '../components/Skills';
const Index = () => {
  return (
    <>
      <Portfolio />
      {/* <Skills /> */}

    </>
  );
};

export default Index;


